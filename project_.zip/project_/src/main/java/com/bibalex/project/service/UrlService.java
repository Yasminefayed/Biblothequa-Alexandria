package com.bibalex.project.service;

import com.bibalex.project.exception.ResourceNotFoundException;
import com.bibalex.project.model.Url;
import com.bibalex.project.repository.UrlRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class UrlService {

    @Autowired
    UrlRepository urlRepository;

    public List<Url> getAllUrls()
    {
        List<Url> urlList = urlRepository.findAll();

        if(urlList.size() > 0) {
            return urlList;
        } else {
            return new ArrayList<Url>();
        }
    }

    public Url getUrlById(Long id) throws ResourceNotFoundException
    {
        Optional<Url> url = urlRepository.findById(id);

        if(url.isPresent()) {
            return url.get();
        } else {
            throw new ResourceNotFoundException("Url", "id", id);
        }
    }

    public long getNumberOfRecords() {
        return urlRepository.count();
    }




}
