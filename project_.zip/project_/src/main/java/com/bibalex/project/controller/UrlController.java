package com.bibalex.project.controller;

import com.bibalex.project.service.UrlService;
import com.bibalex.project.util.Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Arrays;
import java.util.List;

@Controller
public class UrlController {

    @Autowired
    UrlService service;

    @GetMapping
    String getUrls(Model model) {
        model.addAttribute("urls", Util.getRandomUrls(5, service));
        return "index";
    }
}
