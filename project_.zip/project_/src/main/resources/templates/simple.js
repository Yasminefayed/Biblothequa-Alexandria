//let links = [
//    {name: "google", url: "http://www.google.com"},
//    {name: "facebook", url: "http://www.facebook.com"}
//];
//let html = ``;
//links.forEach(link =>
//    html += `<li><a href=${link.url}>${link.name}</a></li></br>`
//);
//
//document.getElementById("links").innerHTML = html;

