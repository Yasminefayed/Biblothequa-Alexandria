package com.bibalex.waybackx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WaybackxApplicationTests {

	@Test
	void contextLoads() {
	}

}
